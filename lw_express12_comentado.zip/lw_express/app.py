# app.py é o ficheiro principal do site: aqui definimos todos os
# endereços (rotas) que existem, tipo /login, /menu, /deposito, etc.
# Cada @app.route liga um endereço a uma função que decide o que
# mostrar quando alguém visita esse endereço.

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify

# Vamos buscar a outros ficheiros ("servicos") as funções que fazem o
# trabalho todo, para o app.py ficar mais organizado — aqui só decidimos
# "o que fazer quando alguém visita este endereço", não "como fazer".
from servicos.autenticacao import validar_login
from servicos.operacoes import obter_saldo
from servicos.dados_pessoais import obter_dados, atualizar_dados
from servicos.cotacao import obter_cotacao
from servicos.conta import depositar, levantar

app = Flask(__name__)

# Chave secreta que o Flask usa para proteger os dados da sessão (o que
# permite ao site "lembrar-se" de quem está com sessão iniciada). Numa
# aplicação real isto devia vir de uma variável de ambiente, e nunca
# ficar escrito diretamente no código.
app.secret_key = "lweiexpressexpresslwei"


# Login
@app.route("/")
def index():
    # Quando alguém visita só o endereço principal do site, mandamos
    # logo para a página de login.
    return redirect("/login")

@app.route("/login", methods=["GET", "POST"])
def login():
    # GET = a pessoa está só a abrir a página (mostramos o formulário).
    # POST = a pessoa já preencheu o formulário e carregou em "Entrar".
    if request.method == "POST":
        utilizador = request.form["utilizador"]
        palavra_passe = request.form["palavra_passe"]

        if validar_login(utilizador, palavra_passe):
            # Credenciais corretas: guardamos o nome do utilizador na
            # sessão, para as próximas páginas saberem quem está a usar
            # o site, e mandamos para o menu principal.
            session["utilizador"] = utilizador
            return redirect("/menu")

        # Credenciais erradas: mostramos o formulário outra vez, com
        # uma mensagem de erro por cima.
        return render_template("login.html", erro="Utilizador ou palavra_passe errada. Tente de novo!")

    return render_template("login.html")

# Menu
@app.route("/menu")
def menu():
    # ⚠️ Esta linha vai dar erro se alguém tentar abrir /menu sem ter
    # feito login primeiro, porque session["utilizador"] ainda não
    # existe. As outras rotas deste ficheiro (exceto /operacoes) têm o
    # mesmo problema: falta o "if 'utilizador' not in session: return
    # redirect('/login')" antes de mexer na sessão.
    username = session["utilizador"]

    # Vai buscar os dados pessoais do utilizador e lê o campo "saldo".
    # Chamamos a este valor "saldo_eur", o que sugere que o dinheiro
    # guardado nesta conta está denominado em Euros.
    dados = obter_dados(username)
    saldo_eur = dados.get("saldo", 0)

    # Pergunta a uma API externa qual é a cotação atual do Euro em
    # Kwanzas, para conseguirmos mostrar o saldo nas duas moedas.
    resultado = obter_cotacao()

    if resultado["sucesso"]:
        taxa = float(resultado["taxa"])
        # ⚠️ Isto divide o saldo em euros pela taxa, mas se "taxa"
        # representa "quantos Kwanzas vale 1 Euro" (ex: 930), então
        # para converter euros -> kwanzas devíamos MULTIPLICAR
        # (saldo_eur * taxa), não dividir. Como está, "saldo_kz" vai
        # sair com um valor muito menor do que devia.
        saldo_kz = round(saldo_eur / taxa, 2)
    else:
        # ⚠️ Se a cotação falhar, só apagamos "saldo_eur" (pondo-o a
        # None), mas "saldo_kz" nunca chega a ser definida neste
        # caminho do código. A linha "saldo_kz=saldo_kz" lá em baixo
        # vai rebentar com um erro (UnboundLocalError) quando isto
        # acontecer.
        saldo_eur = None

    return render_template(
        "menu.html",
        saldo_eur=saldo_eur,
        saldo_kz=saldo_kz,
        resultado=resultado
    )
 
# Deposito
@app.route("/deposito", methods=["GET", "POST"])

def deposito():
    if request.method == "POST":
        # O valor do formulário chega sempre como texto, por isso
        # convertemos para número (float). Se a pessoa escrever algo
        # que não seja um número, isto rebentaria — daí o try/except
        # para apanhar o erro com jeito, em vez de crashar feio.
        try:
            valor = float(request.form.get("valor"))
        except (TypeError, ValueError):
            flash("Valor inválido.")
            return redirect("/deposito")

        if valor <= 0:
            flash("O valor deve ser maior que zero.")
            return redirect("/deposito")

        moeda = request.form.get("moeda")

        if moeda == "EUR":
            # Se a pessoa escolheu depositar em Euros, mas a carteira
            # só guarda um valor em Kwanzas, primeiro convertemos.
            resultado = obter_cotacao()
            if not resultado["sucesso"]:
                flash("Não foi possível obter a cotação.")
                return redirect("/deposito")

            taxa = float(resultado["taxa"])
            valor_eur = round(valor * taxa, 2)
        else:
            # Se já é KZ, não há nada a converter.
            valor_eur = valor

        # Nota: apesar do nome "valor_eur", o que está a ser guardado
        # aqui já está em Kwanzas — o nome da variável é enganador.
        sucesso = depositar(session["utilizador"], valor_eur)

        if sucesso:
            if moeda == "EUR":
                flash(f"Depósito de {valor} EUR ({valor_eur} KZ) efetuado com sucesso!")
            else:
                flash(f"Depósito de {valor_eur} KZ efetuado com sucesso!")
        else:
            flash("Erro ao efetuar o depósito.")

        return redirect("/menu")

    # Se não foi um POST, é só a pessoa a abrir a página do formulário.
    return render_template("deposito.html")

# Levantamento
@app.route("/levantamento", methods=["GET", "POST"])

def levantamento():
    if request.method == "POST":
        try:
            valor = float(request.form.get("valor"))
        except (TypeError, ValueError):
            flash("Valor inválido.")
            return redirect("/levantamento")

        if valor <= 0:
            flash("O valor deve ser maior que zero.")
            return redirect("/levantamento")

        moeda = request.form.get("moeda")

        if moeda == "EUR":
            resultado = obter_cotacao()
            if not resultado["sucesso"]:
                flash("Não foi possível obter a cotação.")
                return redirect("/levantamento")

            taxa = float(resultado["taxa"])
            valor_eur = round(valor * taxa, 2)
        else:
            valor_eur = valor

        # ⚠️ A função levantar() (em servicos/conta.py) não verifica se
        # há saldo suficiente antes de subtrair — ver os comentários
        # nesse ficheiro. Isto significa que, tal como o código está
        # agora, é possível o saldo ficar negativo.
        sucesso = levantar(session["utilizador"], valor_eur)

        if sucesso:
            if moeda == "EUR":
                flash(f"Levantamento de {valor} EUR ({valor_eur} KZ) efetuado com sucesso!")
            else:
                flash(f"Levantamento de {valor_eur} KZ efetuado com sucesso!")
        else:
            flash("Erro ao efetuar o levantamento.")

        return redirect("/menu")

    return render_template("levantamento.html")

# Operaçoes
@app.route("/operacoes")
def operacoes():
    # Esta é a única rota do ficheiro que verifica se a pessoa está
    # mesmo com sessão iniciada antes de mostrar a página. Seria bom
    # ter esta mesma verificação em todas as outras rotas também.
    if "utilizador" not in session:
        return redirect("/login")
   
    return render_template("operacoes.html")

# Dados Pessoais
@app.route("/dados-pessoais", methods=["GET", "POST"])
def dados_pessoais():
    if request.method == "POST":
        novo_telefone = request.form.get("telefone")
        novo_email = request.form.get("email")

        sucesso = atualizar_dados(session["utilizador"], novo_telefone, novo_email)

        if sucesso:
            flash("Dados atualizados com sucesso!")
        else:
            flash("Erro ao atualizar os dados.")

        return redirect("/dados-pessoais")

    dados = obter_dados(session["utilizador"])
    return render_template("dados_pessoais.html", dados=dados)

# Cotação
@app.route("/cotacao")
def cotacao():
    # Mostra a cotação atual — não depende de nenhum utilizador em
    # concreto, por isso não precisa de saldo nem de dados pessoais.
    resultado = obter_cotacao()
    return render_template("cotacao.html", resultado=resultado)

# Logout
@app.route("/logout")
def logout():
    # Apaga tudo o que estava guardado na sessão (esquece o
    # utilizador) e manda de volta para a página de login.
    session.clear()  
    return redirect("/login")  

# Isto só corre quando executamos "python app.py" diretamente.
# debug=True faz o servidor reiniciar sozinho sempre que gravamos
# alterações no código, e mostra páginas de erro mais detalhadas —
# ótimo durante o desenvolvimento, mas deve ser desligado antes de um
# dia isto ir para produção a sério.
if __name__ == "__main__":
    app.run(debug=True)
