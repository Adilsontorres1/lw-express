import mysql.connector

def get_db_connection():

    connection = mysql.connector.connect(
        host="62.28.39.135",
        user="cet0125",
        password="123.Abc",
        database="cet0125_01_lweiexpress"
    )

    return connection
