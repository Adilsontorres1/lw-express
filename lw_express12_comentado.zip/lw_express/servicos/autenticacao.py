import json
import os

def validar_login(utilizador, palavra_passe):
    """
    Recebe o que a pessoa escreveu no formulário de login e verifica se
    coincide com algum utilizador guardado no ficheiro utilizador.json.

    Devolve True se as credenciais estiverem corretas, ou False em
    qualquer outro caso (utilizador não existe, senha errada, ou o
    ficheiro de dados nem sequer existir).
    """
    caminho = os.path.join("dados", "utilizador.json")

    # Se o ficheiro de utilizadores não existir por algum motivo, não
    # há como validar ninguém — devolvemos False em vez de deixar o
    # programa rebentar com um erro.
    if not os.path.exists(caminho):
        return False

    with open(caminho, "r", encoding="utf-8") as f:
        dados = json.load(f)

    # "dados" é um dicionário onde cada chave é o nome de um
    # utilizador, por isso conseguimos verificar diretamente se
    # "utilizador" está lá dentro.
    if utilizador in dados:
        return dados[utilizador]["senha"] == palavra_passe

    return False
