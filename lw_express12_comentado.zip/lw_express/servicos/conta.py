# Este ficheiro trata dos movimentos de dinheiro (depositar e levantar),
# mexendo diretamente no campo "saldo" dentro de utilizador.json.

import json
import os

CAMINHO = os.path.join("dados", "utilizador.json")

def depositar(username, valor_eur):
    """
    Soma 'valor_eur' ao saldo guardado do utilizador.
    Devolve True se correu bem, ou False se algo falhou (utilizador
    não encontrado, valor inválido, ou erro a gravar o ficheiro).
    """
    try:
        with open(CAMINHO, "r", encoding="utf-8") as f:
            dados = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return False

    if username not in dados:
        return False

    if valor_eur <= 0:
        return False

    # .get("saldo", 0) devolve 0 se o utilizador ainda não tiver nenhum
    # saldo guardado, evitando um erro por chave em falta.
    saldo_atual = dados[username].get("saldo", 0)
    dados[username]["saldo"] = saldo_atual + valor_eur

    try:
        with open(CAMINHO, "w", encoding="utf-8") as f:
            json.dump(dados, f, indent=4, ensure_ascii=False)
    except Exception:
        return False

    return True
    
def levantar(username, valor_eur):
    """
    Subtrai 'valor_eur' do saldo guardado do utilizador.

    ⚠️ Reparar que esta função NÃO verifica se o utilizador tem saldo
    suficiente antes de subtrair — ao contrário do que o nome
    "levantar" normalmente implicaria. Isto significa que, com o
    código como está, o saldo pode ficar negativo sem nenhum aviso.
    Seria importante acrescentar algo como:
        if saldo_atual < valor_eur:
            return False
    antes de calcular o novo saldo.
    """
    try:
        with open(CAMINHO, "r", encoding="utf-8") as f:
            dados = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return False

    if username not in dados:
        return False

    if valor_eur  <= 0:
        return False

    saldo_atual = dados[username].get("saldo", 0)
    dados[username]["saldo"] = saldo_atual - valor_eur

    try:
        with open(CAMINHO, "w", encoding="utf-8") as f:
            json.dump(dados, f, indent=4, ensure_ascii=False)
    except Exception:
        return False

    return True
