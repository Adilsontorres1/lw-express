# Este ficheiro só faz uma coisa: perguntar a uma API externa qual é a
# cotação atual entre o Euro e o Kwanza.

import requests

def obter_cotacao():
    """
    Vai buscar a cotação Euro -> Kwanza à AwesomeAPI e devolve um
    dicionário fácil de usar:
      - se correu bem: {"sucesso": True, "taxa": ..., "data": ...}
      - se falhou:      {"sucesso": False, "erro": "explicação"}

    Este formato com "sucesso" True/False ajuda quem chama esta função
    a saber logo se pode confiar no valor, sem ter de adivinhar.
    """
    url = "https://economia.awesomeapi.com.br/json/last/EUR-AOA"
    try:
        resposta = requests.get(url, timeout=10)

        # Se o servidor responder com um erro (por exemplo 404 ou 500),
        # esta linha faz saltar logo para o "except" abaixo.
        resposta.raise_for_status()

        dados = resposta.json()

        # A resposta desta API vem organizada com a chave "EURAOA"
        # (as duas moedas coladas), e dentro dela "bid" é o valor da
        # cotação e "create_date" é quando foi calculada.
        par = dados["EURAOA"]
        taxa = par["bid"]
        data = par["create_date"]

        return {
            "sucesso": True,
            "taxa": taxa,
            "data": data
        }

    except Exception as e:
        # Isto apanha qualquer problema: sem internet, servidor em
        # baixo, resposta em formato inesperado, etc. Em vez de deixar
        # a aplicação crashar, devolvemos um erro organizado que as
        # páginas HTML sabem mostrar com jeito.
        return {
            "sucesso": False,
            "erro": str(e)
        }
