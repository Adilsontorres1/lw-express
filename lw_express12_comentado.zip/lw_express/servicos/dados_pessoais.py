# Trata dos dados pessoais do utilizador (nome, email, telefone, e
# também o campo "saldo", que aqui vive misturado com o resto — ver a
# nota mais abaixo).

import json
import os

CAMINHO = os.path.join("dados", "utilizador.json")

def obter_dados(username):
    """
    Vai buscar ao ficheiro utilizador.json os dados de uma pessoa em
    concreto. Se ela não existir, devolve None em vez de dar erro.
    """
    with open(CAMINHO, "r", encoding="utf-8") as f:
        dados = json.load(f)

    return dados.get(username, None)

def atualizar_dados(username, telefone, email):
    """
    Atualiza o telefone e o email guardados de um utilizador.
    Devolve True se correu tudo bem, ou False se algo falhou (o
    ficheiro não existe, está corrompido, ou o utilizador não existe).
    """
    try:
        with open(CAMINHO, "r", encoding="utf-8") as f:
            dados = json.load(f)
    except FileNotFoundError:
        print("Arquivo não encontrado.")
        return False
    except json.JSONDecodeError:
        # Isto acontece se o ficheiro JSON estiver mal formatado (por
        # exemplo, se foi editado à mão e ficou com uma vírgula a mais
        # ou a menos).
        print("Arquivo JSON inválido ou corrompido.")
        return False

    if username in dados:
        dados[username]["telefone"] = telefone
        dados[username]["email"] = email

        try:
            with open(CAMINHO, "w", encoding="utf-8") as f:
                json.dump(dados, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"Erro ao salvar os dados: {e}")
            return False

        return True

    print("Utilizador não encontrado.")
    return False

# Nota: o campo "saldo" do utilizador vive dentro deste mesmo ficheiro
# utilizador.json (é lido em app.py através de obter_dados()), o que
# significa que os dados pessoais e o saldo da conta estão misturados
# no mesmo sítio. Isto funciona, mas fica mais confuso de gerir do que
# ter o dinheiro guardado à parte, num ficheiro só para carteiras
# (como o dados/carteira.json, que aliás já existe no projeto mas não
# está a ser usado para isto).
