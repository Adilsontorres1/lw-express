# ⚠️ NOTA IMPORTANTE sobre este ficheiro inteiro: nenhuma das funções
# aqui dentro é chamada em nenhum outro lado do projeto (confirmei com
# uma pesquisa a todos os outros ficheiros). Guardam e leem dados de
# dados/carteira.json, com dois saldos separados (KZ e EUR) — uma
# arquitetura diferente da usada pelo resto do projeto, que guarda um
# único saldo dentro de utilizador.json (ver servicos/conta.py e
# servicos/dados_pessoais.py).
#
# Ou seja: existem hoje DUAS "carteiras" diferentes no projeto, uma
# usada de verdade (utilizador.json) e outra que existe mas está
# esquecida (carteira.json, gerida por este ficheiro). Isto costuma
# acontecer quando se experimentam duas abordagens diferentes ao
# longo do desenvolvimento e uma delas fica esquecida sem ser apagada.

import json
import os

CAMINHO = "dados/carteira.json"


def _carregar_dados():
    """Lê o ficheiro carteira.json e devolve o seu conteúdo como dicionário."""
    if not os.path.exists(CAMINHO):
        return {}

    with open(CAMINHO, "r", encoding="utf-8") as f:
        return json.load(f)


def _guardar_dados(dados):
    """Escreve o dicionário de volta no ficheiro."""
    with open(CAMINHO, "w", encoding="utf-8") as f:
        json.dump(dados, f, indent=4, ensure_ascii=False)


def obter_saldo(email):
    """
    Devolve (saldo_kz, saldo_eur) do utilizador. Se for a primeira vez
    que este email aparece, cria uma carteira nova com tudo a zero.
    """
    dados = _carregar_dados()

    if email not in dados:
        dados[email] = {
            "saldo_kz": 0.0,
            "saldo_eur": 0.0,
            "historico": []
        }
        _guardar_dados(dados)

    saldo_kz = dados[email]["saldo_kz"]
    saldo_eur = dados[email]["saldo_eur"]

    return saldo_kz, saldo_eur


def atualizar_saldo(email, valor, moeda, tipo_operacao):
    """
    Soma (ou subtrai, se 'valor' for negativo) um montante ao saldo da
    moeda indicada, e regista a operação no histórico deste utilizador.
    """
    dados = _carregar_dados()

    if email not in dados:
        dados[email] = {
            "saldo_kz": 0.0,
            "saldo_eur": 0.0,
            "historico": []
        }

    if moeda == "KZ":
        dados[email]["saldo_kz"] += valor
    elif moeda == "EUR":
        dados[email]["saldo_eur"] += valor

    dados[email]["historico"].append({
        "tipo": tipo_operacao,
        "valor": valor,
        "moeda": moeda
    })

    _guardar_dados(dados)


def mostrar_historico(email):
    """Devolve a lista de operações já feitas por este utilizador."""
    dados = _carregar_dados()

    if email not in dados:
        return []

    return dados[email]["historico"]
